public interface LineUpStrategy
{
    public abstract void arrange(int a[]);
}
